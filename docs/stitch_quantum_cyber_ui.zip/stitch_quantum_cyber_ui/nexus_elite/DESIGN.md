---
name: Nexus Elite
colors:
  surface: '#0c160a'
  surface-dim: '#0c160a'
  surface-bright: '#313c2e'
  surface-container-lowest: '#071106'
  surface-container-low: '#141e12'
  surface-container: '#182216'
  surface-container-high: '#222d20'
  surface-container-highest: '#2d382a'
  on-surface: '#dae6d2'
  on-surface-variant: '#b9ccb2'
  inverse-surface: '#dae6d2'
  inverse-on-surface: '#283326'
  outline: '#84967e'
  outline-variant: '#3b4b37'
  surface-tint: '#00e639'
  primary: '#ebffe2'
  on-primary: '#003907'
  primary-container: '#00ff41'
  on-primary-container: '#007117'
  inverse-primary: '#006e16'
  secondary: '#b5cdb3'
  on-secondary: '#213522'
  secondary-container: '#394e3a'
  on-secondary-container: '#a7bfa5'
  tertiary: '#f8f8ff'
  on-tertiary: '#2d3137'
  tertiary-container: '#d9dce5'
  on-tertiary-container: '#5d6168'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#72ff70'
  primary-fixed-dim: '#00e639'
  on-primary-fixed: '#002203'
  on-primary-fixed-variant: '#00530e'
  secondary-fixed: '#d0e9ce'
  secondary-fixed-dim: '#b5cdb3'
  on-secondary-fixed: '#0c200f'
  on-secondary-fixed-variant: '#374c38'
  tertiary-fixed: '#dfe2eb'
  tertiary-fixed-dim: '#c3c6cf'
  on-tertiary-fixed: '#181c22'
  on-tertiary-fixed-variant: '#43474e'
  background: '#0c160a'
  on-background: '#dae6d2'
  surface-variant: '#2d382a'
  cyber-green: '#00FF41'
  forest-deep: '#081C09'
  surface-charcoal: '#0D0D0D'
  border-glow: rgba(0, 255, 65, 0.15)
  glass-fill: rgba(255, 255, 255, 0.03)
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: 0.05em
  button-text:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-padding: 24px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style

This design system establishes a **"Cyber-Enterprise"** aesthetic—a fusion of high-stakes industrial management and premium, futuristic software. It targets professionals in high-intensity environments who require a "command center" experience that is both authoritative and remarkably sleek.

The visual direction utilizes a refined mix of **Minimalism** and **Glassmorphism**. By leaning into deep charcoal surfaces and vibrant neon accents, the UI evokes a sense of "Elite OS" status. It avoids the cluttered tropes of "hacker" aesthetics, instead focusing on high-fidelity execution: precise borders, subtle glowing states, and clean, spacious card layouts. The result is a system that feels technical and advanced, yet remains grounded in professional utility.

## Colors

The palette is anchored by **Cyber Green**, a high-chroma accent that signals action and system status. This is balanced against a foundational hierarchy of deep blacks and forest greens to provide extreme contrast and visual comfort in low-light environments.

- **Primary (Cyber Green):** Reserved for primary actions, critical status indicators, and active selection states.
- **Secondary (Forest Deep):** Used for subtle gradients and background depth to soften the transition from pure black.
- **Surface (Charcoal):** The primary canvas color, ensuring a premium, unified appearance across all modules.
- **Glow Accents:** Low-opacity variations of Cyber Green are used for "soft lighting" effects on borders and active containers.

## Typography

This system uses **Inter** (as a high-fidelity alternative to San Francisco) to provide a neutral, premium feel that maximizes legibility. To lean into the "NEXUS/OS" technical narrative, **JetBrains Mono** is introduced for metadata, versioning, and status labels.

Headlines should be set with tight tracking to appear more impactful and "engineered." Body text maintains generous line height for readability. Use the monospaced font sparingly—primarily for system status (e.g., "INITIALIZING...") and numerical data—to maintain the professional dashboard aesthetic without drifting into "retro-terminal" territory.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid** grid. Sidebars and navigation panels occupy fixed widths, while the primary content area stretches to fill available space using a 12-column system.

- **Grid:** 12 columns for desktop, 8 for tablet, and 4 for mobile.
- **Rhythm:** An 8px linear scale governs all spacing. 
- **Density:** High-density information is preferred for data tables, while "Initialization" and entry screens utilize wide margins and centered stacks to create a focused, premium entry point.
- **Reflow:** On mobile, complex dashboard cards stack vertically, and horizontal scrolling is permitted only for wide data tables.

## Elevation & Depth

Hierarchy is achieved through **Tonal Layering** and **Glassmorphism** rather than traditional drop shadows. 

1.  **Base Layer:** Solid `#0D0D0D` charcoal.
2.  **Container Layer:** Translucent surfaces (`glass-fill`) with a `blur(12px)` backdrop filter.
3.  **Active Layer:** Containers feature a 1px solid border in `border-glow` to simulate a subtle light-leak or neon-tube effect.
4.  **Shadows:** When used, shadows are "Ambient Glows"—highly diffused (40px+ blur) with a hint of green saturation (#00FF41 at 5-10% opacity) to make active elements appear as if they are floating above a light source.

## Shapes

The shape language is **Soft (0.25rem)**. This slight rounding removes the "aggression" of sharp 90-degree corners found in brutalist designs, moving the system toward a "precision-milled" industrial look.

- **Primary Buttons:** Use a standard 4px or 8px radius (depending on scale). Avoid full pills to maintain a more structural, architectural feel.
- **Cards:** 12px (`rounded-lg`) to provide a clear distinction between the container and the internal elements.
- **Inputs:** Match button corner radius for visual harmony in forms.

## Components

- **Buttons:** Primary buttons are solid Cyber Green with black text. Secondary buttons use a "ghost" style: transparent fill with a 1px Cyber Green border and a subtle hover glow.
- **Chips/Badges:** Use JetBrains Mono text. Backgrounds are low-opacity tints of the status color (e.g., Status: Active = Cyber Green at 10% opacity).
- **Cards:** Must feature a subtle 1px border. For "Elite" tier content, use a gradient border that transitions from Cyber Green to transparent.
- **Input Fields:** Darker than the base surface (`#050505`). On focus, the border transitions to Cyber Green with a subtle outer glow. Label text is always pinned above the field in a smaller, monospaced font.
- **Lists:** Rows are separated by thin, low-contrast dividers (rgba(255,255,255,0.05)). Hover states should trigger a full-row translucent highlight.
- **Progress Bars:** Represented as segmented blocks or high-intensity glowing lines to reinforce the "System OS" theme.